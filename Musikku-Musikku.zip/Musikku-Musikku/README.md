<h1><p align="center"><a>𝙈𝙐𝙎𝙄𝙆  𝙆𝙐</a><p/><h1/>
<p align="center"><a href="https://github.com/kenkansaja/Musikku"><img src="https://telegra.ph/file/7286ea5b5a2f8dc66e3ed.jpg"width="300"heigh="100" /></a></p>



ᴍᴜsɪᴋ  ᴋᴜ  ᴀᴅᴀʟᴀʜ  ʀᴇᴘᴏ  ᴄʟᴏɴᴇ  ᴅᴀʀɪ  [ʏᴜᴋᴋɪᴍᴜsɪᴄʙᴏᴛ](https://github.com/TeamYukki/YukkiMusicBot)  ᴛᴀᴘɪ  ʏᴀɴɢ  sᴜᴅᴀʜ  ᴅɪ  ʙᴀʜᴀsᴀ  ɪɴᴅᴏɴᴇsɪᴀᴋᴀɴ  ᴏʟᴇʜ  sᴀʏᴀ,  sᴀʏᴀ  ᴀᴅᴀʟᴀʜ  ᴋᴀɴɢᴇʀ  ʙᴜᴋᴀɴ  ᴄᴏᴅᴇʀ  ᴅᴀɴ  sᴀʏᴀ  ᴍᴀsɪʜ  ᴀᴍᴀᴛɪʀᴀɴ  ᴏᴋᴇʏ

## DEPLOY DI HEROKU

<p align="center"><a href="https://ice-iota-kohl.vercel.app"><img src="https://telegra.ph/file/6630257821911f10089b5.jpg" /></a></p>
<p align="center"><a href="https://telegram.dog/XTZ_HerokuBot?start=a2Vua2Fuc2FqYS9NdXNpa2t1IE11c2lra3U"><img src="https://telegra.ph/file/70966bb4b212649afc8dc.jpg" /></a></p>


## DEPLOY OKTETO

<a href="https://cloud.okteto.com/deploy?repository=https://github.com/kenkansaja/Musikku"><img src="https://img.shields.io/badge/Deploy%20To%20Okteto-informational?style=for-the-badge&logo=Okteto" width="200"/></a>

## STRINGS SESSION PYROGRAM

<p align="center"><a href="https://replit.com/@kenkannih/strings-session#main.py"><img src="https://img.shields.io/badge/REPLIT-STRINGS-yellow?style=plastic&logo=replit&logoColor=yellow"width="270" height="40" /></a></p>

<p align="center">
<a href="https://t.me/Stringdurhakabot"><img src="https://img.shields.io/badge/STRING-BOT-green?style=plastic&logo=Telegram"width="270" height="40"  /></a>
<a href="https://t.me/kenkanrobot"><img src="https://img.shields.io/badge/BOT API HASH-DAN APP ID-gold?style=plastic&logo=Telegram&logoColor=yellow"width="270" height="40" /></a>
</p>

## COMMAND ADMINS 🧑‍✈️

- c = adalah singkatan dari pemutaran channel
- /pause atau /cpause - Menjeda musik yang sedang diputar.
- /resume atau /cresume- Melanjutkan musik yang dijeda.
- /mute atau /cmute- Mematikan musik yang diputar.
- /unmute atau /cunmute- Mengaktifkan musik yang dimatikan.
- /skip atau /cskip- Lewati musik yang sedang diputar.
- /stop atau /cstop- Menghentikan pemutaran musik.
- /shuffle atau /cshuffle- Secara acak mengacak daftar putar yang antri.

## COMMAND MEMBERS 👥
- /play atau /vplay atau /cplay - Bot akan mulai memainkan kueri yang Anda berikan pada obrolan suara.

- /stream atau /cstream - Streaming tautan langsung di obrolan suara.

- /channelplay [Nama pengguna atau id obrolan] atau [Nonaktifkan] - Hubungkan saluran ke grup dan streaming musik di obrolan suara saluran dari grup Anda.
## DEPLOY VPS
Nih kak cara deploy di vps
```console
musikku@musikku$ git clone https://github.com/kenkansaja/Musikku
musikku@musikku$ cd Musikku
musikku@musikku$ bash setup
musikku@musikku$ screen -S Musikku
musikku@musikku$ bash start
```
## ORIGINAL REPO
> Terimakasih untuk [@NotReallyShikhar](https://github.com/NotReallyShikhar) dan [Team Yukki](https://github.com/TeamYukki) Untuk sumber code nya, saya hanyalah kangger oke.

- [YukkiMusicBot](https://github.com/TeamYukki/YukkiMusicBot) - Original Repo

## CONTRIBUTOR
Terimakasih
- [@NotReallyShikhar](https://github.com/NotReallyShikhar) - Dev
- [@kenkansaja](https://github.com/kenkansaja) - Kanger
- [@Toni880](https://github.com/Toni880) - Lord Ujian


### Mari terhubung!
<p>
    <a href="https://t.me/kenkanasw" target="blank"><img src="https://img.shields.io/badge/@kenkanasw-30302f?style=flat&logo=telegram"width="254" height="52"/></a>
    <a href="https://t.me/musikkugroup" target="blank"><img src="https://img.shields.io/badge/MUSIK KU GROUP-black?style=flat&logo=telegram"width="319" height="52"/></a>
    <a href="https://t.me/musikkuchannel" target="blank"><img src="https://img.shields.io/badge/MUSIK KU CHANNEL-gold?style=flat&logo=telegram"width="332" height="49"/></a>
</p>
